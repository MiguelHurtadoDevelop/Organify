<template>
        <img src="/ORGANIFY_LOGO.png" alt="Logo" />
</template>
