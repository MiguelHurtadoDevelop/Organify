<table class="subcopy" width="100%" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td>
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
<?php /**PATH C:\Users\Miguel Hurtado\Desktop\ProyectoFinal\Proyecto_Final_Miguel_Hurtado\organify\vendor\laravel\framework\src\Illuminate\Mail/resources/views/html/subcopy.blade.php ENDPATH**/ ?>