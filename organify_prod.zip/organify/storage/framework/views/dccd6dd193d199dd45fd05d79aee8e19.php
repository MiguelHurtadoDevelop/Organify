<?php echo e($slot); ?>

<?php /**PATH C:\Users\Miguel Hurtado\Desktop\ProyectoFinal\Proyecto_Final_Miguel_Hurtado\organify\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>