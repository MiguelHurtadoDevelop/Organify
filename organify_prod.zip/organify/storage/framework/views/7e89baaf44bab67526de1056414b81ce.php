<?php echo e($slot); ?>

<?php /**PATH C:\Users\Miguel Hurtado\Desktop\ProyectoFinal\Proyecto_Final_Miguel_Hurtado\organify\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>